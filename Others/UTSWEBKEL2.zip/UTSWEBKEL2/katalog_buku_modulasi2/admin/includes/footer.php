<footer class="main-footer">
    <strong>Copyright &copy; 2021 <a href="http://vokasi.ub.ac.id">Vokasi UB</a>.</strong>
    All rights reserved.
  </footer>